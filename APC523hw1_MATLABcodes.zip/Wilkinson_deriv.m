function y = Wilkinson_deriv(x)

    syms X
    func = 1;
    for k = 1:20
        func = (X-k)*func;
    end
    C = double(coeffs(func));

    y = 0;
    for k = 1:21
        y = y+C(k)*(k-1)*x^(k-2);
    end

end