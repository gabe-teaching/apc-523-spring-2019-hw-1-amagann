

%% Problem 2

clear
clc

x = 5.5; k = 30; m = 5;

% Part (a)
Nums_a = zeros(31,1); Nums_a(1) = 1;
Denoms_a = zeros(31,1); Denoms_a(1) = 1;
for n = 1:k
    Nums_a(n+1) = round(Nums_a(n)*x,m,'significant');
    Denoms_a(n+1) = round(Denoms_a(n)*n,m,'significant');
end

% part (b)
Approx_b = 0;
for n = 1:k+1
    Approx_b = round(Approx_b + round(Nums_a(n)/Denoms_a(n),m,'significant'),m,'significant');
end
Approx_b % answer is 244.71
% answer has converged at k=17 (18 total terms)
Exact = exp(x); % answer is 244.6919322...
RE = (exp(x)-Approx_b)/exp(x) % relative error = -7.384e-5

% part (c)
Approx_c = 0;
for n = 1:k+1
    Approx_c = round(round(Nums_a(n)/Denoms_a(n),m,'significant')+Approx_c,m,'significant');
end
Approx_c % No this didn't change any answers

% part (d)
x_d = -5.5;
for n = 1:k+1
    Nums_d(n) = (-1)^(n-1)*Nums_a(n);
    Denoms_d(n) = Denoms_a(n);
end
Terms = round(Nums_d./Denoms_d,m,'significant');

% (i) Always add left to right
Approx_di = 0;
for n = 1:k+1
    Approx_di = round(Approx_di + Terms(n),m,'significant');
end
Approx_di % answer is 0.0038363
% answer has converged at k=25 (26 total terms)
Exact_d = exp(x_d); % answer is 0.0040867714...
RE_di = (exp(x_d)-Approx_di)/exp(x_d) % relative error = 0.061288...


% (ii) Within each partial sum, add right to left
Approx_dii = 0;
for n = 1:k+1
    Approx_dii = round(Terms(n)+Approx_dii,m,'significant');
end
Approx_dii % answer is 0.0038363
% answer has converged at k=25 (26 total terms)
RE_dii = (exp(x_d)-Approx_dii)/exp(x_d) % relative error = 0.061288...


% (iii) add all the positive terms contributing to partial sum left to right, then add all...
%       the negative terms left to right, and then combine those results.
Terms_pos = Terms; Terms_pos(Terms_pos < 0) = 0;
Terms_neg = Terms; Terms_neg(Terms_neg > 0) = 0;

Approx_diii = 0; 
for n = 1:k+1
    pos = 0; neg = 0;
    for n2 = 1:n
        pos = round(pos + Terms_pos(n2),m,'significant');
        neg = round(neg + Terms_neg(n2),m,'significant');
    end
    Approx_diii = round(pos+neg,m,'significant');
end
Approx_diii % answer is 0.0000
% answer has converged at k=17 (18 total terms)
RE_diii = (exp(x_d)-Approx_diii)/exp(x_d) % relative error = 1


% (iv) add all the positive terms contributing to partial sum right to left, then add all...
%       the negative terms right to left, and then combine those results.
Approx_div = 0; 
for n = 1:k+1
    pos = 0; neg = 0;
    for n2 = 1:n
        pos = round(Terms_pos(n2)+pos,m,'significant');
        neg = round(Terms_neg(n2)+neg,m,'significant');
    end
    Approx_div = round(pos+neg,m,'significant');
end
Approx_div % answer is 0.0000
% answer has converged at k=17 (18 total terms)
RE_diii = (exp(x_d)-Approx_div)/exp(x_d) % relative error = 1


% iii and iv converge most quickly, but the answer is very wrong

% i and ii have lowest error

% Compared with positive case, exp(-5.5) is much more difficult to compute
%       accurately


% part (e) 

% One way which would probably work better would be to compute exp(5.5)
% rather than exp(-5.5), using the series approach as per parts (b) and
% (c). Then, once exp(5.5) is calculated, just take exp(-5.5) = 1/exp(5.5).
% Division does not introduce a lot of error, so this should improve the
% accuracy of the result. 

% Validate proposal - just take inverse of what I already have from parts
% (b) and (c)

Approx_e = 1/Approx_b % we get exp(-5.5) = 0.00408647... 
RE_e = (exp(x_d)-Approx_e)/exp(x_d)

% This took only 18 terms and has a RE of 7.38e-05, compared with 26 terms
% using the method in part (d) which had a RE of 0.061288. 
% So, we see this is a much better approach!


%% Problem 4

% part (c)
x = 0:0.01:1;
condA = (x./abs(1-exp(-x)))./x;
condf = (x.*exp(-x))./(1-exp(-x));
figure
subplot(2,1,1)
hold on
plot(x,condA,'k','LineWidth',2)
plot(x,condf,'k:','LineWidth',2')
plot(x,ones(size(x)),'r--','LineWidth',1.5)
hold off
title('Zoomed out')
xlabel('x')
ylabel('condA(x), condf(x)')
legend('condA','condf','1.0')
axis([0 1 0 100])
subplot(2,1,2)
hold on
plot(x,condA,'k','LineWidth',2)
plot(x,condf,'k:','LineWidth',2')
plot(x,ones(size(x)),'r--','LineWidth',1.5)
hold off
title('Zoomed in')
xlabel('x')
ylabel('condA(x), condf(x)')
legend('condA','condf','1.0')
axis([0 1 0 2.5])

% we see that condA(x) becomes more ill-conditioned for smaller x values.
% This is because the expression for condA(x) involves division by x, so
% the expression diverges in the limit of x goes to zero. On a higher
% level, the algorithm is ill conditioned due to the subtraction operation,
% when we subtract something from 1 which is very close to 1 (i.e. exp(0) in
% this case)

% part (d)
% smallest x for 1 bit of significance lost:
%      condA(x) = 2 when x = 0.69 (i.e., error is 2eps)

% smallest x for 2 bits significance lost
%      condA(x) = 4 when x = 0.28 (i.e., error is 4eps = 2^2 = 2 bits)

% smallest x for 3 bits significance lost
%      condA(x) = 8 when x = 0.13 (i.e., error is 8eps = 2^3 = 3 bits)

% smallest x for 4 bits significance lost
%      condA(x) = 16 when x = 0.06 (i.e., error is 16eps = 2^4 = 4 bits)


%% Problem 5

clear
clc

dif = 1;
e_old = 0;
e_table = [];
j = 0;
TOL = 13;
while dif >0
    n = 10^j;
    e = (1+(1/n))^n;
    dif = round(e,TOL,'significant')-round(e_old,TOL,'significant');
    e_old = e;
    e_table(j+1) = e;
    j = j+1;
end
e % congerges to 2.7161100
nstop = n % nstop is 10^13
jstop = j-1 % jstop is 13
e_table'

% issue is probably that at *some* point the nonzero digits in (1+1/n) get too spread apart for machine
% precision to account for them both when we do the exponential, so taking the
% exponential starts giving inaccurate results after this point is reached.

%% Problem 6

clear
clc

x = linspace(1,10,1001);
x0 = x';
n = 52;

for j = 1:n
    x = sqrt(x);
    j = j;
end
x1 = x';

for k = 1:n
    x = x.^2;
    k = k;
end
x2 = x';

figure
hold on
plot(x0,x2,'r','LineWidth',2)
plot(x0,x0,'k--')

% Analysis of what happens if we square-root & square different numbers
% of times
vals = [49 50 51 53 54];
y = zeros(1001,length(vals));
for j = 1:length(vals)
    n = vals(j);
    y1 = x0;
    for k2 = 1:n
        y1 = sqrt(y1);
        k2 = k2;
    end
    y(:,j) = y1;
    y2 = y1;

    for k = 1:n
        y2 = y2.^2;
        k = k;
    end
    
    y(:,j) = y2;

end

figure
hold on
plot(x0,y,'LineWidth',1.5)
plot(x0,x2,'r','LineWidth',2)
plot(x0,x0,'k--')
legend('49','50','51','53','54')

% what values left intact and why? Give account of what's going on

% with 52 iterations we get correct results for e^0, e^1, and e^2

% with 51 iterations, extra recovered values at e^0, e^0.5, e^1, e^1.5, and e^2 
% with 50 iterations, additional extra recovered values at e^(1/4), e^(3/4), e^(5/4), e^(7/4), e^(9/4)

% with 53 iterations, only e^0 and  e^2 are recovered 
% with 54 iterations, only e^0 recovered 

% we see that with increased numbers of iterations, we are converging
% towards everything resulting in 1. This is because 1 is the fixed point
% of the square root & squaring maps. When we see that, below 54
% iterations, we converge also to other powers of e. This can be explained
% by looking at the expression for e given in Problem 5, which is:
% e = lim n->\infty (1+1/n)^n
% we see that for very large n, 1/n becomes very small, and (1+1/n) will become hard to represent accurately.
% then, it is possible that taking 52 square roots of a number will make it
% look like (1+1/n) for (some) very large n, and the computer could store
% the number as an inverse n-th power of e. Then, when we square it 52 more
% times, we will effectively be squaring some inverse n-th power of e 52
% times, and the result will be (e^(1/n))^2^2^2....50-some times, which
% will lead to a result with is a power of e or a fractional power of e. In
% the limit of infinite iterations we will get the fixed point of the map,
% exp(0)=1, but with fewer and fewer iterations we will get closer and
% closer to the correct answers. But somewhere in between (in the upper
% 40-s, lower 50-s range), we will see the "powers of e" behavior as an
% artifact of the situation described above.

%% Problem 7

clear 
clc

syms X
func = 1;

% part (a)
for k = 1:20
    func = (X-k)*func;
end
C = coeffs(func); % C contains a vector with the integer coefficients

% part (b)
% y = Wilkinson2(x); % The Wilkinson function evaluates the polynomial for a
% given x argument
x0 = 21;
options = optimset('TolX',10^(-12));
x_b = fsolve(@(x) Wilkinson2(x, 0,0), x0,options) % evaluates to 21.00000

% part (c)
delta = [10^(-8) 10^(-6) 10^(-4) 10^(-2)];
for j = 1:length(delta)
    x_c = fsolve(@(x) Wilkinson2(x, delta(j),0), x0,options)
end
% In order from 10^-8 to 10^-2, I get: 20.9999, 13.7238, 7.70882, and
% 5.4470; we see the largest root starts shrinking!

% part (d)
x_d = fsolve(@(x) Wilkinson2(x, 0, -2*10^(-23)), x0,options) % this gives me 21.00000068
x_d = fsolve(@(x) Wilkinson2(x, 0, -2*10^(-23)),16,options) % this gives me 16
x_d = fsolve(@(x) Wilkinson2(x, 0, -2*10^(-23)),17,options) % this gives me 17.00000023

% part (e) part (ii) 
r = [14 16 17 20];
for j = 1:length(r)
    dpdr = Wilkinson_deriv(r(j));
    for l = 1:x0-1
        cond = C(l)*r(j)^(l-1)/dpdr;
    end
    cond_e = double(cond)
end
% answers are -2.8e11, -5.1e11, 4.0000e11, and -9.1e9, in order
% These large values indicate that the problem is indeed very poorly conditioned!


%% Problem 8

clear
clc

N = 32; % seed value
yn=0;
for n = 1:12
    yn=(exp(1)-yn)/(N); % reversed recurrence reln
    N = N-1;
end
y20=yn
% this gives yn = 0.1238038
% Wolfram gives yn = 0.1238 as well






