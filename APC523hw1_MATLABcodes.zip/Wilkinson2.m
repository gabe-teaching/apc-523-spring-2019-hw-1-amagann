function y = Wilkinson2(x,delta,delta2)

    syms X
    func = 1;
    for k = 1:20
        func = (X-k)*func;
    end
    C = double(coeffs(func));
    C(end) = C(end)+delta;
    C(end-1) = C(end-1)+delta2;

    y = 0;
    for k = 1:21
        y = y+C(k)*x^(k-1);
    end

end